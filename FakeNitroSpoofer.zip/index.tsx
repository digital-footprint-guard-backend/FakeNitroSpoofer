import { ReactNative as RN, React } from "@metro/common";

const {
    View,
    Text,
    Pressable,
    ScrollView,
    StyleSheet,
    Animated,
} = RN;

const themes = {
    "Nitro Dark": {
        background: "#111214",
        card: "#1b1d20",
        border: "#292b2f",
        accent: "#5865f2",
        text: "#ffffff",
        muted: "#96989d",
    },

    "AMOLED": {
        background: "#000000",
        card: "#090909",
        border: "#181818",
        accent: "#5865f2",
        text: "#ffffff",
        muted: "#888888",
    },

    "Purple": {
        background: "#140d1d",
        card: "#21142e",
        border: "#33203f",
        accent: "#9b59ff",
        text: "#ffffff",
        muted: "#aa9bb8",
    },

    "Pink": {
        background: "#1c0c14",
        card: "#2a141f",
        border: "#3d1d2c",
        accent: "#ff69a9",
        text: "#ffffff",
        muted: "#b99ba9",
    },

    "Blue": {
        background: "#0b111c",
        card: "#141e2d",
        border: "#24344b",
        accent: "#4aa3ff",
        text: "#ffffff",
        muted: "#98a8ba",
    },
};

type ThemeName = keyof typeof themes;

let settings = {
    enabled: true,
    profileEffects: true,
    customBadge: true,
    animatedUI: true,
    localBanner: true,
    chatCosmetics: true,
    theme: "Nitro Dark" as ThemeName,
};

function getTheme() {
    return themes[settings.theme];
}

function saveSettings() {
    try {
        // @ts-ignore Kettu runtime
        if (typeof vendetta !== "undefined" && vendetta.plugin?.storage) {
            vendetta.plugin.storage.settings = settings;
        }
    } catch {}
}

function loadSettings() {
    try {
        // @ts-ignore Kettu runtime
        const saved =
            typeof vendetta !== "undefined"
                ? vendetta.plugin?.storage?.settings
                : undefined;

        if (saved) {
            settings = {
                ...settings,
                ...saved,
            };
        }
    } catch {}
}

function Switch({
    value,
    accent,
    onPress,
}: {
    value: boolean;
    accent: string;
    onPress: () => void;
}) {
    return (
        <Pressable
            onPress={onPress}
            style={[
                styles.switch,
                {
                    backgroundColor: value ? accent : "#45474c",
                },
            ]}
        >
            <View
                style={[
                    styles.switchDot,
                    {
                        alignSelf: value
                            ? "flex-end"
                            : "flex-start",
                    },
                ]}
            />
        </Pressable>
    );
}

function SettingRow({
    title,
    description,
    value,
    accent,
    onPress,
}: {
    title: string;
    description: string;
    value: boolean;
    accent: string;
    onPress: () => void;
}) {
    return (
        <View style={styles.row}>
            <View style={styles.rowContent}>
                <Text style={styles.rowTitle}>{title}</Text>

                <Text style={styles.rowDescription}>
                    {description}
                </Text>
            </View>

            <Switch
                value={value}
                accent={accent}
                onPress={onPress}
            />
        </View>
    );
}

function ThemeRow({
    name,
    selected,
    accent,
    onPress,
}: {
    name: ThemeName;
    selected: boolean;
    accent: string;
    onPress: () => void;
}) {
    const theme = themes[name];

    return (
        <Pressable
            onPress={onPress}
            style={[
                styles.themeRow,
                {
                    borderColor: selected
                        ? accent
                        : "#292b2f",
                },
            ]}
        >
            <View
                style={[
                    styles.themePreview,
                    {
                        backgroundColor: theme.background,
                    },
                ]}
            >
                <View
                    style={[
                        styles.themePreviewCard,
                        {
                            backgroundColor: theme.card,
                        },
                    ]}
                />
            </View>

            <View style={styles.themeText}>
                <Text style={styles.rowTitle}>
                    {name}
                </Text>

                <Text style={styles.rowDescription}>
                    {selected
                        ? "Currently selected"
                        : "Select theme"}
                </Text>
            </View>

            <View
                style={[
                    styles.radio,
                    {
                        borderColor: selected
                            ? accent
                            : "#55575c",
                    },
                ]}
            >
                {selected && (
                    <View
                        style={[
                            styles.radioInner,
                            {
                                backgroundColor: accent,
                            },
                        ]}
                    />
                )}
            </View>
        </Pressable>
    );
}

function Section({
    title,
    children,
}: {
    title: string;
    children: React.ReactNode;
}) {
    return (
        <View style={styles.section}>
            <Text style={styles.sectionTitle}>
                {title}
            </Text>

            {children}
        </View>
    );
}

function FakeNitroSettings() {
    loadSettings();

    const theme = getTheme();

    const toggle = (key: keyof typeof settings) => {
        const current = settings[key];

        if (typeof current !== "boolean") return;

        settings[key] = !current as never;
        saveSettings();
    };

    return (
        <View
            style={[
                styles.container,
                {
                    backgroundColor: theme.background,
                },
            ]}
        >
            <ScrollView
                contentContainerStyle={
                    styles.scrollContent
                }
            >
                {/* HEADER */}

                <View style={styles.header}>
                    <View
                        style={[
                            styles.logo,
                            {
                                backgroundColor:
                                    theme.accent,
                            },
                        ]}
                    >
                        <Text style={styles.logoText}>
                            F
                        </Text>
                    </View>

                    <View>
                        <Text style={styles.title}>
                            FakeNitro
                        </Text>

                        <Text
                            style={[
                                styles.subtitle,
                                {
                                    color: theme.muted,
                                },
                            ]}
                        >
                            Nitro-style customization
                        </Text>
                    </View>
                </View>

                {/* STATUS */}

                <View
                    style={[
                        styles.statusCard,
                        {
                            backgroundColor:
                                theme.card,
                            borderColor:
                                theme.border,
                        },
                    ]}
                >
                    <View>
                        <Text style={styles.statusTitle}>
                            FakeNitro
                        </Text>

                        <Text
                            style={[
                                styles.statusText,
                                {
                                    color: theme.muted,
                                },
                            ]}
                        >
                            Visual customization active
                        </Text>
                    </View>

                    <View
                        style={[
                            styles.statusDot,
                            {
                                backgroundColor:
                                    settings.enabled
                                        ? "#43b581"
                                        : "#747f8d",
                            },
                        ]}
                    />
                </View>

                {/* GENERAL */}

                <Section title="General">
                    <SettingRow
                        title="Enable FakeNitro"
                        description="Enable visual customization."
                        value={settings.enabled}
                        accent={theme.accent}
                        onPress={() =>
                            toggle("enabled")
                        }
                    />

                    <SettingRow
                        title="Animated UI"
                        description="Enable cosmetic animations."
                        value={settings.animatedUI}
                        accent={theme.accent}
                        onPress={() =>
                            toggle("animatedUI")
                        }
                    />
                </Section>

                {/* PROFILE */}

                <Section title="Profile">
                    <SettingRow
                        title="Profile Effects"
                        description="Show local cosmetic profile effects."
                        value={settings.profileEffects}
                        accent={theme.accent}
                        onPress={() =>
                            toggle("profileEffects")
                        }
                    />

                    <SettingRow
                        title="Custom Badge"
                        description="Show a local cosmetic badge."
                        value={settings.customBadge}
                        accent={theme.accent}
                        onPress={() =>
                            toggle("customBadge")
                        }
                    />

                    <SettingRow
                        title="Local Banner"
                        description="Enable local banner presentation."
                        value={settings.localBanner}
                        accent={theme.accent}
                        onPress={() =>
                            toggle("localBanner")
                        }
                    />
                </Section>

                {/* CHAT */}

                <Section title="Chat">
                    <SettingRow
                        title="Chat Cosmetics"
                        description="Enable local message cosmetics."
                        value={settings.chatCosmetics}
                        accent={theme.accent}
                        onPress={() =>
                            toggle("chatCosmetics")
                        }
                    />
                </Section>

                {/* THEMES */}

                <Section title="Themes">
                    {(
                        Object.keys(
                            themes,
                        ) as ThemeName[]
                    ).map((name) => (
                        <ThemeRow
                            key={name}
                            name={name}
                            selected={
                                settings.theme === name
                            }
                            accent={theme.accent}
                            onPress={() => {
                                settings.theme =
                                    name;

                                saveSettings();
                            }}
                        />
                    ))}
                </Section>

                {/* PREVIEW */}

                <Section title="Preview">
                    <View style={styles.preview}>
                        <View
                            style={[
                                styles.previewAvatar,
                                {
                                    backgroundColor:
                                        theme.accent,
                                },
                            ]}
                        >
                            <Text
                                style={
                                    styles.previewAvatarText
                                }
                            >
                                F
                            </Text>
                        </View>

                        <View>
                            <View
                                style={
                                    styles.previewNameRow
                                }
                            >
                                <Text
                                    style={
                                        styles.previewName
                                    }
                                >
                                    FakeNitro User
                                </Text>

                                {settings.customBadge && (
                                    <View
                                        style={[
                                            styles.badge,
                                            {
                                                backgroundColor:
                                                    theme.accent,
                                            },
                                        ]}
                                    >
                                        <Text
                                            style={
                                                styles.badgeText
                                            }
                                        >
                                            N
                                        </Text>
                                    </View>
                                )}
                            </View>

                            <Text
                                style={[
                                    styles.previewMessage,
                                    {
                                        color:
                                            theme.muted,
                                    },
                                ]}
                            >
                                Nitro-style local preview
                            </Text>
                        </View>
                    </View>
                </Section>

                {/* CREDITS */}

                <View style={styles.credits}>
                    <Text
                        style={[
                            styles.creditText,
                            {
                                color: theme.muted,
                            },
                        ]}
                    >
                        Made by{" "}
                        <Text
                            style={{
                                color: theme.accent,
                                fontWeight: "800",
                            }}
                        >
                            @Jesus is my God
                        </Text>
                    </Text>

                    <Text
                        style={[
                            styles.creditSubtext,
                            {
                                color: theme.muted,
                            },
                        ]}
                    >
                        FakeNitro • Kettu
                    </Text>
                </View>
            </ScrollView>
        </View>
    );
}

function onLoad() {
    console.log("[FakeNitro] Loaded");
}

function onUnload() {
    console.log("[FakeNitro] Unloaded");
}

export default {
    onLoad,
    onUnload,

    settings: FakeNitroSettings,
};