(vendetta => {
const React = vendetta.metro.common.React;
const ReactNative = vendetta.metro.common.ReactNative;

const {
    View,
    Text,
    Pressable,
    ScrollView,
    StyleSheet
} = ReactNative;

const { plugin } = vendetta;

const storage = plugin.storage;

const defaults = {
    enabled: true,
    profileEffects: true,
    customBadge: true,
    animatedUI: true,
    localBanner: true,
    chatCosmetics: true,
    theme: "Nitro Dark"
};

const themes = {
    "Nitro Dark": {
        background: "#111214",
        card: "#1E1F22",
        accent: "#5865F2",
        text: "#FFFFFF",
        muted: "#B5BAC1"
    },
    "AMOLED": {
        background: "#000000",
        card: "#0A0A0A",
        accent: "#5865F2",
        text: "#FFFFFF",
        muted: "#A0A0A0"
    },
    "Purple": {
        background: "#160D24",
        card: "#241337",
        accent: "#A970FF",
        text: "#FFFFFF",
        muted: "#C7B8D9"
    },
    "Pink": {
        background: "#210F18",
        card: "#351722",
        accent: "#FF6BBA",
        text: "#FFFFFF",
        muted: "#D8B6C6"
    },
    "Blue": {
        background: "#0B1724",
        card: "#122538",
        accent: "#4DA6FF",
        text: "#FFFFFF",
        muted: "#AFC8DD"
    }
};

let settings = Object.assign({}, defaults, storage.settings || {});

function save() {
    storage.settings = settings;
}

function toggle(key) {
    settings[key] = !settings[key];
    save();
}

function SwitchRow({ title, description, setting }) {
    return React.createElement(
        Pressable,
        {
            onPress: () => toggle(setting),
            style: styles.row
        },
        React.createElement(
            View,
            { style: styles.rowText },
            React.createElement(Text, { style: styles.title }, title),
            React.createElement(Text, { style: styles.description }, description)
        ),
        React.createElement(
            View,
            {
                style: [
                    styles.switch,
                    settings[setting] && styles.switchOn
                ]
            },
            React.createElement(
                View,
                {
                    style: [
                        styles.knob,
                        settings[setting] && styles.knobOn
                    ]
                }
            )
        )
    );
}

function ThemeButton({ name }) {
    const theme = themes[name];
    const selected = settings.theme === name;

    return React.createElement(
        Pressable,
        {
            onPress: () => {
                settings.theme = name;
                save();
            },
            style: [
                styles.themeButton,
                {
                    borderColor: selected
                        ? theme.accent
                        : "#33353A"
                }
            ]
        },
        React.createElement(
            View,
            {
                style: [
                    styles.themeDot,
                    { backgroundColor: theme.accent }
                ]
            }
        ),
        React.createElement(
            Text,
            {
                style: [
                    styles.themeText,
                    selected && { color: theme.accent }
                ]
            },
            name
        )
    );
}

function Section({ title, children }) {
    return React.createElement(
        View,
        { style: styles.section },
        React.createElement(
            Text,
            { style: styles.sectionTitle },
            title
        ),
        React.createElement(
            View,
            { style: styles.card },
            children
        )
    );
}

function FakeNitroSettings() {
    const theme = themes[settings.theme] || themes["Nitro Dark"];

    return React.createElement(
        ScrollView,
        {
            style: {
                flex: 1,
                backgroundColor: theme.background
            },
            contentContainerStyle: styles.container
        },

        React.createElement(
            View,
            {
                style: [
                    styles.header,
                    { borderBottomColor: theme.accent }
                ]
            },
            React.createElement(
                Text,
                { style: styles.logo },
                "FAKE NITRO"
            ),
            React.createElement(
                Text,
                { style: styles.subtitle },
                "Local cosmetic customization"
            )
        ),

        React.createElement(
            View,
            {
                style: [
                    styles.status,
                    { backgroundColor: theme.card }
                ]
            },
            React.createElement(
                Text,
                { style: styles.statusTitle },
                settings.enabled
                    ? "● FakeNitro Enabled"
                    : "○ FakeNitro Disabled"
            ),
            React.createElement(
                Text,
                { style: styles.statusText },
                "Visual effects are local to your client."
            )
        ),

        React.createElement(
            Section,
            { title: "GENERAL" },

            React.createElement(SwitchRow, {
                title: "Enable FakeNitro",
                description: "Enable local FakeNitro cosmetics.",
                setting: "enabled"
            }),

            React.createElement(SwitchRow, {
                title: "Animated UI",
                description: "Enable cosmetic animations.",
                setting: "animatedUI"
            })
        ),

        React.createElement(
            Section,
            { title: "PROFILE" },

            React.createElement(SwitchRow, {
                title: "Profile Effects",
                description: "Show local profile-style effects.",
                setting: "profileEffects"
            }),

            React.createElement(SwitchRow, {
                title: "Custom Badge",
                description: "Display a local cosmetic badge.",
                setting: "customBadge"
            }),

            React.createElement(SwitchRow, {
                title: "Local Banner",
                description: "Enable local profile banner styling.",
                setting: "localBanner"
            })
        ),

        React.createElement(
            Section,
            { title: "CHAT" },

            React.createElement(SwitchRow, {
                title: "Chat Cosmetics",
                description: "Enable local chat cosmetic styling.",
                setting: "chatCosmetics"
            })
        ),

        React.createElement(
            Section,
            { title: "THEME" },
            Object.keys(themes).map(name =>
                React.createElement(ThemeButton, {
                    key: name,
                    name: name
                })
            )
        ),

        React.createElement(
            View,
            {
                style: [
                    styles.preview,
                    { backgroundColor: theme.card }
                ]
            },
            React.createElement(
                Text,
                { style: styles.previewTitle },
                "LOCAL PREVIEW"
            ),

            React.createElement(
                Text,
                {
                    style: [
                        styles.previewName,
                        { color: theme.accent }
                    ]
                },
                "Nitro-style Profile"
            ),

            React.createElement(
                Text,
                { style: styles.previewText },
                "This is a visual preview only."
            )
        ),

        React.createElement(
            View,
            { style: styles.footer },

            React.createElement(
                Text,
                { style: styles.footerText },
                "FakeNitro"
            ),

            React.createElement(
                Text,
                { style: styles.credit },
                "Made by @Jesus is my God"
            ),

            React.createElement(
                Text,
                { style: styles.disclaimer },
                "Client-side cosmetic customization • No Nitro entitlement spoofing"
            )
        )
    );
}

const styles = StyleSheet.create({
    container: {
        padding: 16,
        paddingBottom: 40
    },

    header: {
        paddingBottom: 14,
        marginBottom: 16,
        borderBottomWidth: 2
    },

    logo: {
        fontSize: 26,
        fontWeight: "900",
        color: "#FFFFFF"
    },

    subtitle: {
        marginTop: 4,
        fontSize: 13,
        color: "#B5BAC1"
    },

    status: {
        padding: 16,
        borderRadius: 12,
        marginBottom: 20
    },

    statusTitle: {
        color: "#FFFFFF",
        fontSize: 16,
        fontWeight: "700"
    },

    statusText: {
        color: "#B5BAC1",
        fontSize: 12,
        marginTop: 5
    },

    section: {
        marginBottom: 20
    },

    sectionTitle: {
        color: "#949BA4",
        fontSize: 12,
        fontWeight: "800",
        marginBottom: 8,
        letterSpacing: 0.5
    },

    card: {
        backgroundColor: "#1E1F22",
        borderRadius: 12,
        overflow: "hidden"
    },

    row: {
        minHeight: 68,
        paddingHorizontal: 15,
        paddingVertical: 12,
        flexDirection: "row",
        alignItems: "center",
        borderBottomWidth: 1,
        borderBottomColor: "#303136"
    },

    rowText: {
        flex: 1,
        paddingRight: 10
    },

    title: {
        color: "#FFFFFF",
        fontSize: 15,
        fontWeight: "600"
    },

    description: {
        color: "#949BA4",
        fontSize: 12,
        marginTop: 4
    },

    switch: {
        width: 44,
        height: 25,
        borderRadius: 13,
        backgroundColor: "#4E5058",
        padding: 3,
        justifyContent: "center"
    },

    switchOn: {
        backgroundColor: "#5865F2"
    },

    knob: {
        width: 19,
        height: 19,
        borderRadius: 10,
        backgroundColor: "#FFFFFF"
    },

    knobOn: {
        alignSelf: "flex-end"
    },

    themeButton: {
        minHeight: 52,
        margin: 7,
        paddingHorizontal: 14,
        borderRadius: 10,
        borderWidth: 1,
        flexDirection: "row",
        alignItems: "center"
    },

    themeDot: {
        width: 16,
        height: 16,
        borderRadius: 8,
        marginRight: 12
    },

    themeText: {
        color: "#FFFFFF",
        fontSize: 14,
        fontWeight: "600"
    },

    preview: {
        padding: 18,
        borderRadius: 12,
        marginBottom: 24
    },

    previewTitle: {
        color: "#949BA4",
        fontSize: 11,
        fontWeight: "800",
        marginBottom: 10
    },

    previewName: {
        fontSize: 18,
        fontWeight: "800"
    },

    previewText: {
        color: "#B5BAC1",
        marginTop: 5,
        fontSize: 12
    },

    footer: {
        alignItems: "center",
        paddingTop: 10
    },

    footerText: {
        color: "#FFFFFF",
        fontSize: 14,
        fontWeight: "800"
    },

    credit: {
        color: "#949BA4",
        fontSize: 12,
        marginTop: 5
    },

    disclaimer: {
        color: "#686B73",
        fontSize: 9,
        textAlign: "center",
        marginTop: 8
    }
});

function onLoad() {
    storage.settings = Object.assign(
        {},
        defaults,
        storage.settings || {}
    );
}

function onUnload() {}

return {
    onLoad,
    onUnload,
    settings: FakeNitroSettings
};

})